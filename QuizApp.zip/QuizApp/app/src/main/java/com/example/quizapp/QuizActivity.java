package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class QuizActivity extends AppCompatActivity {

    private TextView questionTextView, timerTextView;
    private RadioGroup answerRadioGroup;
    private Button nextButton;

    private CountDownTimer countDownTimer;
    private long timeLeft = 10000; // 10 seconds per question

    private int currentQuestionIndex = 0;
    private int score = 0;
    private String[] questions;
    private String[][] options;
    private int[] correctAnswers;

    private String difficulty;
    private String username; // Current user
    private DatabaseHelper dbHelper; // SQLite

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // --- Apply saved theme ---
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // --- Initialize UI elements ---
        questionTextView = findViewById(R.id.questionTextView);
        timerTextView = findViewById(R.id.timerTextView);
        answerRadioGroup = findViewById(R.id.answerRadioGroup);
        nextButton = findViewById(R.id.nextButton);

        // --- Database helper ---
        dbHelper = new DatabaseHelper(this);

        // --- Get username and difficulty from intent or pref ---
        username = getIntent().getStringExtra("username");
        if (username == null) username = "demoUser"; // default for testing
        difficulty = getIntent().getStringExtra("difficulty");
        if (difficulty == null) difficulty = "easy";

        // --- Check if user already attempted this quiz ---
        if (dbHelper.hasAttemptedQuiz(username, difficulty)) {
            Toast.makeText(this, "You have already attempted this quiz", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // --- Initialize quiz data ---
        initializeQuizData(difficulty);

        // --- Load first question ---
        loadQuestion();

        nextButton.setOnClickListener(view -> {
            if (answerRadioGroup.getCheckedRadioButtonId() != -1) {
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.length) {
                    loadQuestion();
                } else {
                    // Save score in SQLite
                    dbHelper.saveScore(username, difficulty, score);

                    // Show result
                    showResult();
                }
            } else {
                Toast.makeText(this, "Select an answer", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initializeQuizData(String difficulty) {
        // --- Your original 10 questions and options ---
        questions = new String[]{
                "What is the capital of France?",
                "What is the capital of Japan?",
                "What is the capital of United States?",
                "What is the capital of Germany?",
                "What is the capital of Canada?",
                "What is the capital of Italy?",
                "What is the capital of United Kingdom?",
                "What is the capital of Australia?",
                "What is the capital of India?",
                "What is the capital of Brazil?"
        };
        options = new String[][]{
                {"Paris", "London", "Berlin", "Madrid"},
                {"Tokyo", "Beijing", "Seoul", "Bangkok"},
                {"Washington D.C", "NewYork", "Los Angeles", "Chicago"},
                {"Berlin", "Munich", "Frankfurt", "Hamburg"},
                {"Toronto", "Ottawa", "Montreal", "Vancouver"},
                {"Rome", "Venice", "Florence", "Milan"},
                {"London", "Edinburgh", "Dublin", "Cardiff"},
                {"Sydney", "Melbourne", "Canberra", "Brisbane"},
                {"New Delhi", "Mumbai", "Bangalore", "Chennai"},
                {"Rio de Janeiro", "São Paulo", "Brasília", "Buenos Aires"}
        };
        correctAnswers = new int[]{0,0,0,0,1,0,0,2,0,2};
    }

    private void loadQuestion() {
        if (countDownTimer != null) countDownTimer.cancel();

        if (currentQuestionIndex < questions.length) {
            questionTextView.setText(questions[currentQuestionIndex]);
            ((RadioButton) answerRadioGroup.getChildAt(0)).setText(options[currentQuestionIndex][0]);
            ((RadioButton) answerRadioGroup.getChildAt(1)).setText(options[currentQuestionIndex][1]);
            ((RadioButton) answerRadioGroup.getChildAt(2)).setText(options[currentQuestionIndex][2]);
            ((RadioButton) answerRadioGroup.getChildAt(3)).setText(options[currentQuestionIndex][3]);

            answerRadioGroup.clearCheck();
            timeLeft = 10000;
            startTimer();
        }
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeft, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeft = millisUntilFinished;
                timerTextView.setText(String.valueOf(timeLeft / 1000));
            }

            @Override
            public void onFinish() {
                timerTextView.setText("0");
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.length) {
                    loadQuestion();
                } else {
                    dbHelper.saveScore(username, difficulty, score);
                    showResult();
                }
            }
        }.start();
    }

    private void checkAnswer() {
        int selectedId = answerRadioGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            int selectedAnswer = answerRadioGroup.indexOfChild(findViewById(selectedId));
            if (selectedAnswer == correctAnswers[currentQuestionIndex]) {
                score++;
            }
            answerRadioGroup.clearCheck();
        }
    }

    private void showResult() {
        Intent intent = new Intent(QuizActivity.this, ResultActivity.class);
        intent.putExtra("score", score);
        intent.putExtra("totalQuestions", questions.length);
        intent.putExtra("difficulty", difficulty);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (countDownTimer != null) countDownTimer.cancel();
        super.onDestroy();
    }
}
