package com.example.quizapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "quizApp.db";
    private static final int DATABASE_VERSION = 2; // Increment if you already had a DB

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    // Scores table
    private static final String TABLE_SCORES = "scores";
    private static final String COLUMN_SCORE_ID = "id";
    private static final String COLUMN_USER = "username";
    private static final String COLUMN_QUIZ_TYPE = "quiz_type";
    private static final String COLUMN_SCORE = "score";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USERNAME + " TEXT,"
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // Create scores table
        String CREATE_SCORES_TABLE = "CREATE TABLE " + TABLE_SCORES + "("
                + COLUMN_SCORE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_USER + " TEXT,"
                + COLUMN_QUIZ_TYPE + " TEXT,"
                + COLUMN_SCORE + " INTEGER)";
        db.execSQL(CREATE_SCORES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORES);
        onCreate(db);
    }

    // --------- USER METHODS ---------
    public boolean addUser(String username, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Add this inside DatabaseHelper class (USER METHODS section)
    public boolean checkUserExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_EMAIL + "=?",
                new String[]{email},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Check login credentials
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COLUMN_USER_ID},
                COLUMN_EMAIL + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{email, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public boolean updatePassword(String email, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PASSWORD, newPassword);
        int rows = db.update(TABLE_USERS, values, COLUMN_EMAIL + "=?", new String[]{email});
        db.close();
        return rows > 0;
    }

    public String getUsername(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USERNAME}, COLUMN_EMAIL + "=?", new String[]{email}, null, null, null);
        if(cursor != null && cursor.moveToFirst()) {
            String username = cursor.getString(0);
            cursor.close();
            db.close();
            return username;
        }
        db.close();
        return null;
    }

    // --------- SCORE METHODS ---------
    public boolean hasAttemptedQuiz(String username, String quizType) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_SCORES,
                new String[]{COLUMN_SCORE_ID},
                COLUMN_USER + "=? AND " + COLUMN_QUIZ_TYPE + "=?",
                new String[]{username, quizType},
                null, null, null);
        boolean attempted = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return attempted;
    }

    public boolean saveScore(String username, String quizType, int score) {
        if(hasAttemptedQuiz(username, quizType)) return false;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER, username);
        values.put(COLUMN_QUIZ_TYPE, quizType);
        values.put(COLUMN_SCORE, score);
        long result = db.insert(TABLE_SCORES, null, values);
        db.close();
        return result != -1;
    }

    public Cursor getScores(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_SCORES, new String[]{COLUMN_QUIZ_TYPE, COLUMN_SCORE}, COLUMN_USER + "=?", new String[]{username}, null, null, null);
    }
}
