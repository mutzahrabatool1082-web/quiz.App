package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView welcomeTextView;
    private Button easyButton, mediumButton, hardButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // --- Apply saved theme before super.onCreate ---
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // Make sure XML file matches

        // Initialize UI elements
        welcomeTextView = findViewById(R.id.welcomeTextView);
        easyButton = findViewById(R.id.easybutton);
        mediumButton = findViewById(R.id.mediumbutton);
        hardButton = findViewById(R.id.hardbutton);
        logoutButton = findViewById(R.id.logoutButton);
        Button viewUsersButton = findViewById(R.id.viewUsersButton);

        viewUsersButton.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, UserListActivity.class));
        });


        // Handle difficulty buttons
        easyButton.setOnClickListener(v -> startQuiz("easy"));
        mediumButton.setOnClickListener(v -> startQuiz("medium"));
        hardButton.setOnClickListener(v -> startQuiz("hard"));

        // Handle logout
        logoutButton.setOnClickListener(v -> {
            // Clear login flag
            prefManager.setLogin(false);

            // Go back to login screen
            Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }

    private void startQuiz(String difficulty) {
        Intent intent = new Intent(HomeActivity.this, QuizActivity.class);
        intent.putExtra("difficulty", difficulty);
        startActivity(intent);
    }
}
