package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ForgotPasswordActivity extends AppCompatActivity {

    private EditText forgotEmailEditText;
    private Button submitForgotButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply theme
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        forgotEmailEditText = findViewById(R.id.forgotEmailEditText);
        submitForgotButton = findViewById(R.id.submitForgotButton);

        submitForgotButton.setOnClickListener(v -> {
            String email = forgotEmailEditText.getText().toString().trim();
            if(email.isEmpty()) {
                Toast.makeText(this, "Enter your registered email", Toast.LENGTH_SHORT).show();
            } else {
                // Optional: check if user exists in DB
                DatabaseHelper db = new DatabaseHelper(this);
                if(!db.checkUserExists(email)) { // add this method
                    Toast.makeText(this, "Email not registered", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Pass email to reset activity
                Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
                intent.putExtra("email", email);
                startActivity(intent);
                finish();
            }
        });

    }
}
