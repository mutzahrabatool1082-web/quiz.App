package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    private EditText usernameEditText, emailEditText, passwordEditText;
    private Button signupButton;
    private TextView loginTextView;
    private PrefManager prefManager;
    private DatabaseHelper dbHelper; // SQLite helper

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply theme
        prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        usernameEditText = findViewById(R.id.usernameEditText);
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        signupButton = findViewById(R.id.signupButton);
        loginTextView = findViewById(R.id.loginTextView);

        // Initialize SQLite helper
        dbHelper = new DatabaseHelper(this);

        signupButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String email = emailEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if(username.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            } else {
                // Insert user into SQLite database
                boolean inserted = dbHelper.addUser(username, email, password);
                if(inserted) {
                    Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignupActivity.this, LoginActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "Email already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginTextView.setOnClickListener(v -> {
            startActivity(new Intent(SignupActivity.this, LoginActivity.class));
            finish();
        });
    }
}
