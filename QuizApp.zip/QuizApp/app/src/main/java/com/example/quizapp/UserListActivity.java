package com.example.quizapp;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class UserListActivity extends AppCompatActivity {

    private ListView usersListView;
    private DatabaseHelper dbHelper;
    private ArrayList<String> usersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply theme
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_list);

        usersListView = findViewById(R.id.usersListView);
        dbHelper = new DatabaseHelper(this);
        usersList = new ArrayList<>();

        loadUsers();
    }

    private void loadUsers() {
        Cursor cursor = dbHelper.getReadableDatabase()
                .query("users", new String[]{"username", "email"}, null, null, null, null, null);

        if(cursor != null && cursor.getCount() > 0) {
            while(cursor.moveToNext()) {
                String username = cursor.getString(0);
                String email = cursor.getString(1);
                usersList.add(username + " (" + email + ")");
            }
            cursor.close();

            ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                    android.R.layout.simple_list_item_1, usersList);
            usersListView.setAdapter(adapter);
        } else {
            Toast.makeText(this, "No users found", Toast.LENGTH_SHORT).show();
        }
    }
}
