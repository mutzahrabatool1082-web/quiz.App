package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView scoreTextView;
    private Button replayButton, homeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // --- Apply saved theme before super.onCreate ---
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result); // Make sure this matches your XML file

        // Initialize UI elements
        scoreTextView = findViewById(R.id.scoreTextView);
        replayButton = findViewById(R.id.replayButton);
        homeButton = findViewById(R.id.homeButton);

        // Get score, total questions, and difficulty from intent
        int score = getIntent().getIntExtra("score", 0);
        int totalQuestions = getIntent().getIntExtra("totalQuestions", 0);
        String difficulty = getIntent().getStringExtra("difficulty");

        // Display the score and difficulty
        scoreTextView.setText("Your score: " + score + "/" + totalQuestions +
                "\nDifficulty: " + (difficulty != null ? difficulty : "easy"));

        // Handle Replay button click
        replayButton.setOnClickListener(view -> {
            Intent replayIntent = new Intent(ResultActivity.this, QuizActivity.class);
            replayIntent.putExtra("difficulty", difficulty); // Replay with same difficulty
            startActivity(replayIntent);
            finish(); // Close result screen
        });

        // Handle Home button click
        homeButton.setOnClickListener(view -> {
            Intent homeIntent = new Intent(ResultActivity.this, HomeActivity.class);
            startActivity(homeIntent); // Go to Home
            finish();
        });
    }
}
