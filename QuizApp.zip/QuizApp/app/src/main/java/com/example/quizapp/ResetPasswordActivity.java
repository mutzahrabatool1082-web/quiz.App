package com.example.quizapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ResetPasswordActivity extends AppCompatActivity {

    private EditText newPasswordEditText, confirmPasswordEditText;
    private Button  resetPasswordButton;
    ;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply theme
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        newPasswordEditText = findViewById(R.id.newPasswordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        resetPasswordButton = findViewById(R.id.resetPasswordButton);

        dbHelper = new DatabaseHelper(this);

        resetPasswordButton.setOnClickListener(v -> {
            String newPass = newPasswordEditText.getText().toString().trim();
            String confirmPass = confirmPasswordEditText.getText().toString().trim();

            if(newPass.isEmpty() || confirmPass.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
            } else if(!newPass.equals(confirmPass)) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                // Retrieve email from intent (passed from ForgotPasswordActivity)
                String email = getIntent().getStringExtra("email");
                if(email == null || email.isEmpty()) {
                    Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean updated = dbHelper.updatePassword(email, newPass);
                if(updated) {
                    Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                    finish(); // go back to login
                } else {
                    Toast.makeText(this, "Failed to update password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
