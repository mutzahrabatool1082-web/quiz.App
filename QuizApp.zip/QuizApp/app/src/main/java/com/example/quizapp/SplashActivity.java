package com.example.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DELAY = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Apply theme
        PrefManager prefManager = new PrefManager(this);
        String theme = prefManager.getTheme();
        switch (theme) {
            case "Theme.QuizApp.Light": setTheme(R.style.Theme_QuizApp_Light); break;
            case "Theme.QuizApp.Dark": setTheme(R.style.Theme_QuizApp_Dark); break;
            case "Theme.QuizApp.Custom": setTheme(R.style.Theme_QuizApp_Custom); break;
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash );

        new Handler().postDelayed(() -> {
            // Check login
            if (prefManager.isLoggedIn()) {
                startActivity(new Intent(SplashActivity.this, HomeActivity.class));
            } else {
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }
            finish();
        }, SPLASH_DELAY);
    }
}
