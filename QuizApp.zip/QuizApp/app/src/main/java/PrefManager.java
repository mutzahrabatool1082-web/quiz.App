package com.example.quizapp; // use your package name

import android.content.Context;
import android.content.SharedPreferences;
public class PrefManager {
    private static final String PREF_NAME = "quiz_app_pref";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";
    private static final String KEY_THEME = "appTheme";

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    public PrefManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    // Login flag
    public void setLogin(boolean value) {
        editor.putBoolean(KEY_IS_LOGGED_IN, value);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    // Theme
    public void setTheme(String themeName) {
        editor.putString(KEY_THEME, themeName);
        editor.apply();
    }

    public String getTheme() {
        return prefs.getString(KEY_THEME, "Theme.QuizApp.Light"); // default light
    }

}
